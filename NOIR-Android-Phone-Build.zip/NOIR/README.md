# NOIR — Android manga & manhwa reader

A native Android starter project built with Kotlin and Jetpack Compose. The UI combines a cinematic, editorial home screen with a clean poster-grid library and a dark translucent floating navigation bar.

## Included in this first milestone
- Home, Discover, Library, Downloads and Profile screens
- Search by title or genre
- Saved / Reading / Completed library filters
- Series detail screen and chapter list
- Reader preview with vertical/paged mode toggle
- Local in-memory bookmarks and reading progress examples
- Dark AMOLED visual system and responsive Compose layouts

## Build an APK using only your phone

This repository includes a GitHub Actions workflow at `.github/workflows/android.yml`. It builds the debug APK in GitHub's cloud; Android Studio and a local Android SDK are not required on your phone.

1. Sign in to GitHub and create a **new empty repository** named `NOIR`.
2. Upload the contents of this project folder to the repository (make sure `.github/workflows/android.yml` is included).
3. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
4. Select **Build NOIR APK** and tap **Run workflow**. Alternatively, pushing to the `main` branch starts a build automatically.
5. When the run finishes successfully, open it, scroll to **Artifacts**, and download `NOIR-debug-APK`.
6. Extract the downloaded ZIP on your Android phone, then tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager; only allow this for the APK you intentionally built from your own repository.

The first build may take several minutes while Gradle downloads dependencies.

## Local build (optional)
Requirements: JDK 17, Android SDK 35, Gradle 8.9.

```bash
gradle --no-daemon :app:assembleDebug
```

## Important current limitations
This is a functional UI/application foundation, not yet a complete content reader. The reader currently shows a preview placeholder. There is no manga source catalogue, parser, CBZ/CBR importer, image paging engine, persistent database, or background download manager yet. Those are planned next milestones and require source-specific implementation and testing.

## Project
- `app/src/main/java/com/noir/reader/MainActivity.kt` — Compose UI and app state
- `app/src/main/AndroidManifest.xml` — app entry point
- `app/build.gradle.kts` — Android and Compose dependencies
- `.github/workflows/android.yml` — cloud APK build
